import { Link } from "react-router-dom";
import { useLang, t } from "@/lib/i18n";
import { Shield, Search, FileCheck, Users, ArrowRight, Sparkles, Globe, Clock } from "lucide-react";

const Landing = () => {
  const { lang } = useLang();

  const features = [
    {
      icon: <Sparkles className="h-6 w-6" />,
      title: t(lang, "AI-Powered Matching", "एआई-संचालित मिलान"),
      desc: t(lang, "Smart algorithm matches you with the most relevant government schemes based on your profile.", "स्मार्ट एल्गोरिदम आपकी प्रोफ़ाइल के आधार पर सबसे प्रासंगिक सरकारी योजनाओं से मिलान करता है।"),
    },
    {
      icon: <FileCheck className="h-6 w-6" />,
      title: t(lang, "Document Checklist", "दस्तावेज़ चेकलिस्ट"),
      desc: t(lang, "Get a complete list of required documents for each scheme you're eligible for.", "प्रत्येक योजना के लिए आवश्यक दस्तावेजों की पूरी सूची प्राप्त करें।"),
    },
    {
      icon: <Globe className="h-6 w-6" />,
      title: t(lang, "Multilingual Support", "बहुभाषी समर्थन"),
      desc: t(lang, "Access the platform in Hindi and English for better accessibility.", "बेहतर पहुंच के लिए हिंदी और अंग्रेजी में प्लेटफ़ॉर्म का उपयोग करें।"),
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: t(lang, "Deadline Tracking", "समय सीमा ट्रैकिंग"),
      desc: t(lang, "Never miss a scheme deadline with our timely reminders and updates.", "हमारे समय पर अनुस्मारक और अपडेट के साथ कभी भी योजना की समय सीमा न चूकें।"),
    },
  ];

  const stats = [
    { number: "500+", label: t(lang, "Government Schemes", "सरकारी योजनाएं") },
    { number: "28+", label: t(lang, "States Covered", "राज्य शामिल") },
    { number: "10L+", label: t(lang, "Citizens Helped", "नागरिकों की मदद") },
    { number: "95%", label: t(lang, "Match Accuracy", "मिलान सटीकता") },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="bg-hero-gradient relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-accent rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-success rounded-full blur-3xl" />
        </div>
        <div className="container mx-auto px-4 py-20 md:py-28 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-primary-foreground/10 text-primary-foreground/90 px-4 py-1.5 rounded-full text-sm mb-6 animate-fade-in">
              <Shield className="h-4 w-4 text-accent" />
              {t(lang, "AI-Powered Government Scheme Platform", "एआई-संचालित सरकारी योजना मंच")}
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-primary-foreground leading-tight mb-6 animate-slide-up">
              {t(lang, "Find Government Schemes ", "सरकारी योजनाएं खोजें ")}
              <span className="text-gradient-hero">
                {t(lang, "You Deserve", "जो आपके लिए हैं")}
              </span>
            </h1>
            <p className="text-primary-foreground/70 text-lg md:text-xl mb-8 max-w-2xl mx-auto animate-slide-up">
              {t(lang,
                "JanSarthi-AI uses artificial intelligence to match you with government schemes based on your profile. Simple, fast, and accurate.",
                "JanSarthi-AI आपकी प्रोफ़ाइल के आधार पर सरकारी योजनाओं से मिलान करने के लिए कृत्रिम बुद्धिमत्ता का उपयोग करता है। सरल, तेज़ और सटीक।"
              )}
            </p>
            <Link
              to="/eligibility"
              className="inline-flex items-center gap-2 bg-saffron-gradient text-accent-foreground px-8 py-4 rounded-lg font-semibold text-lg hover:opacity-90 transition-all shadow-lg hover:shadow-xl animate-scale-in"
            >
              <Search className="h-5 w-5" />
              {t(lang, "Check Your Eligibility", "अपनी पात्रता जांचें")}
              <ArrowRight className="h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-card border-b">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <div key={i} className="text-center animate-slide-up" style={{ animationDelay: `${i * 100}ms` }}>
                <div className="text-3xl md:text-4xl font-extrabold text-primary">{stat.number}</div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 md:py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-3">
              {t(lang, "How JanSarthi-AI Helps You", "JanSarthi-AI आपकी कैसे मदद करता है")}
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              {t(lang, "Our platform simplifies access to government benefits for every citizen.", "हमारा मंच प्रत्येक नागरिक के लिए सरकारी लाभों तक पहुंच को सरल बनाता है।")}
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f, i) => (
              <div
                key={i}
                className="bg-card rounded-lg border p-6 hover:shadow-md transition-all duration-300 animate-slide-up"
                style={{ animationDelay: `${i * 100}ms` }}
              >
                <div className="h-12 w-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-4">
                  {f.icon}
                </div>
                <h3 className="font-semibold text-card-foreground mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Impact */}
      <section className="py-16 bg-secondary/50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Users className="h-10 w-10 text-primary mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-foreground mb-4">
              {t(lang, "Bridging the Digital Divide", "डिजिटल खाई को पाटना")}
            </h2>
            <p className="text-muted-foreground mb-8">
              {t(lang,
                "Millions of eligible citizens miss out on government benefits due to lack of awareness. JanSarthi-AI uses AI to ensure no citizen is left behind. Our platform has helped lakhs of citizens discover and apply for schemes they didn't know existed.",
                "जागरूकता की कमी के कारण लाखों पात्र नागरिक सरकारी लाभों से वंचित रह जाते हैं। JanSarthi-AI यह सुनिश्चित करने के लिए एआई का उपयोग करता है कि कोई भी नागरिक पीछे न रहे।"
              )}
            </p>
            <Link
              to="/eligibility"
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-lg font-medium hover:opacity-90 transition-opacity"
            >
              {t(lang, "Get Started Now", "अभी शुरू करें")}
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Landing;
