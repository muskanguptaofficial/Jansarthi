import { useLocation, Link } from "react-router-dom";
import { useLang, t } from "@/lib/i18n";
import { EligibilityResult } from "@/lib/eligibility";
import { UserProfile } from "@/lib/eligibility";
import SchemeCard from "@/components/SchemeCard";
import { ArrowLeft, Sparkles } from "lucide-react";

const Results = () => {
  const { lang } = useLang();
  const location = useLocation();
  const { results, profile } = (location.state as { results: EligibilityResult[]; profile: UserProfile }) || {
    results: [],
    profile: null,
  };

  if (!profile) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <p className="text-muted-foreground mb-4">{t(lang, "No results found. Please fill the form first.", "कोई परिणाम नहीं मिला। कृपया पहले फॉर्म भरें।")}</p>
        <Link to="/eligibility" className="text-primary font-medium hover:underline">
          {t(lang, "Go to Eligibility Form", "पात्रता फॉर्म पर जाएं")}
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-10">
      <div className="container mx-auto px-4 max-w-4xl">
        <Link
          to="/eligibility"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          {t(lang, "Back to Form", "फॉर्म पर वापस जाएं")}
        </Link>

        <div className="text-center mb-8 animate-fade-in">
          <div className="inline-flex items-center gap-2 bg-success/10 text-success px-4 py-1.5 rounded-full text-sm font-medium mb-4">
            <Sparkles className="h-4 w-4" />
            {t(lang, `${results.length} Schemes Found`, `${results.length} योजनाएं मिलीं`)}
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            {t(lang, "Your Eligible Schemes", "आपकी पात्र योजनाएं")}
          </h1>
          <p className="text-muted-foreground">
            {t(lang, "Based on your profile, here are the top government schemes for you.", "आपकी प्रोफ़ाइल के आधार पर, यहां आपके लिए शीर्ष सरकारी योजनाएं हैं।")}
          </p>
        </div>

        {results.length > 0 ? (
          <div className="grid gap-4">
            {results.map((r, i) => (
              <SchemeCard key={r.scheme.id} result={r} index={i} />
            ))}
          </div>
        ) : (
          <div className="bg-card rounded-xl border p-8 text-center">
            <p className="text-muted-foreground">
              {t(lang, "No schemes matched your profile. Try adjusting your details.", "आपकी प्रोफ़ाइल से कोई योजना मेल नहीं खाई। अपना विवरण बदलकर देखें।")}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Results;
